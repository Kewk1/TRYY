﻿

Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Dboard

    Public q As String
    Private Sub Stockbtn_Click(sender As Object, e As EventArgs) Handles Stockbtn.Click
    End Sub
    Private Sub Dboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoggedUser.Text = My.Forms.Loginform.LoginUser

        ' BindGd()
        'Usrtyp()


    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        EditUser()
        My.Forms.Loginform.Txtbox1.Clear()
        My.Forms.Loginform.Txtbox2.Clear()

    End Sub


    Private Sub EditUser()

        'q = "insert into UserLoginAudit values('" & My.Forms.Loginform.Txtbox1.Text & "','" & My.Forms.Loginform.Txtbox2.Text & "','" & My.Forms.Loginform.Cmbox.Text & "',' OUT ',' " & DateTime.Now & "')"
        Dim cmd As New SqlCommand("INSERT INTO UserLoginAudit VALUES(@txt1, @txt2, @txt3, 'OUT', @date1)")
        cmd.Parameters.AddWithValue("@txt1", My.Forms.Loginform.Txtbox1.Text)
        cmd.Parameters.AddWithValue("@txt2", My.Forms.Loginform.Txtbox2.Text)
        cmd.Parameters.AddWithValue("@txt3", My.Forms.Loginform.Cmbox.Text)
        cmd.Parameters.Add("@date1", SqlDbType.Date).Value = DateTime.Now
        If (InsertData(cmd)) Then
            Application.Exit()
        End If


    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Loghist.Show()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        RegForm.Show()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Maintenance.Show()
    End Sub


    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        SellItem.Show()
    End Sub


    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles PictureBox5.Click
        Item1.Show()

    End Sub

    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) Handles PictureBox6.Click
        StockItem.Show()
    End Sub

    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles PictureBox7.Click
        Salesfrm.Show()

    End Sub

    Private Sub PictureBox8_Click(sender As Object, e As EventArgs) Handles PictureBox8.Click
        Loginform.Show()
        My.Forms.Loginform.Txtbox1.Clear()
        My.Forms.Loginform.Txtbox2.Clear()
        My.Forms.Loginform.Button1.Enabled = False
        My.Forms.Loginform.Button2.Show()


    End Sub

    ' Public Sub Usrtyp()
    'qr = "select * from UserLogin where UserType = '" & My.Forms.Loginform.Cmbox.SelectedItem.text & "'" Then
    'Dim logincorrect As Boolean = Convert.ToBoolean(InsertData(qr))
    '    If (logincorrect) Then

    ' TextBox2.Text = "admin"
    '  Else
    '  TextBox2.Text = "staff"
    '
    '  End If

    '  End If
    ' End Sub


End Class