﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class AdminLog

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Admin.Click
        Dim username As String = TextBox1.Text
        Dim password As String = TextBox2.Text

        If (Isformvalid()) Then
            qr = "select * from Userlogin where Username='" & TextBox1.Text & "' and password='" & TextBox2.Text & "'"
            ds = Searchdata(qr)
            If (ds.Tables(0).Rows.Count > 0) Then
                ds = Searchdata(qr)

                'UserType = Cmbox.Text
                ' EditUser()
                'Admin()
                ' Dboard.Show()
                'AdminLog.Show()

                Dboard.Show()
                Me.Hide()

            Else
                MsgBox("Incorrect Username or Password", MsgBoxStyle.Critical)
                Dboard.Hide()

            End If
        End If
        ' Add your admin login logic here
        'If IsAdmin(username, password) Then
        'MessageBox.Show("Admin login successful")
        ' Navigate to the admin dashboard or perform other actions
        '  Else
        ' MessageBox.Show("Invalid admin credentials")
        '  End If


    End Sub

    Private Function Isformvalid() As Boolean
        If (TextBox1.Text.Trim() = String.Empty) Then
            MsgBox("Username is required", MsgBoxStyle.Critical)
            TextBox1.Clear()
            TextBox2.Clear()
            Return False

        End If

        If (TextBox2.Text.Trim() = String.Empty) Then
            MsgBox("Password is required", MsgBoxStyle.Critical)
            TextBox1.Clear()
            TextBox2.Clear()
            Return False
        End If


        ' If (Cmbox.SelectedIndex = -1) Then
        'MsgBox("Choose User", MsgBoxStyle.Critical)
        'Txtbox1.Clear()
        'Txtbox2.Clear()


        'urn False
        ' End If
        Return True

    End Function


    ' Private Function IsAdmin(username As String, password As String) As Boolean
    ' Replace this with your actual admin authentication logic
    'Return username = "admin" AndAlso password = "adminpassword"
    ' Function

    Private Sub Button1_Click_1(sender As Object, e As EventArgs)

        Dim adminLog As New AdminLog()
        adminLog.ShowDialog()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Dim staffLogin As New StaffLogin()
        staffLogin.ShowDialog()
    End Sub
End Class

