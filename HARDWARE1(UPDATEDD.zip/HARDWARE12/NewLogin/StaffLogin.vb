﻿Public Class StaffLogin
    Private Sub StaffLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim username As String = TextBox1.Text
        Dim password As String = TextBox2.Text

        If (Isformvalid()) Then
            qr = "select * from StaffLogin where Username='" & TextBox1.Text & "' and password='" & TextBox2.Text & "'"
            ds = Searchdata(qr)
            If (ds.Tables(0).Rows.Count > 0) Then
                ds = Searchdata(qr)

                'UserType = Cmbox.Text
                ' EditUser()
                'Admin()
                ' Dboard.Show()
                'AdminLog.Show
                ' Me.Hide()

                Dboard.Show()
                Me.Hide()
                My.Forms.Dboard.PictureBox3.Visible = False
                Dboard.Show()
            Else
                MsgBox("Incorrect Username or Password", MsgBoxStyle.Critical)


            End If
        End If


    End Sub


    Private Function Isformvalid() As Boolean
        If (TextBox1.Text.Trim() = String.Empty) Then
            MsgBox("Username is required", MsgBoxStyle.Critical)
            TextBox1.Clear()
            TextBox2.Clear()
            Return False

        End If

        If (TextBox2.Text.Trim() = String.Empty) Then
            MsgBox("Password is required", MsgBoxStyle.Critical)
            TextBox1.Clear()
            TextBox2.Clear()
            Return False
        End If


        ' If (Cmbox.SelectedIndex = -1) Then
        'MsgBox("Choose User", MsgBoxStyle.Critical)
        'Txtbox1.Clear()
        'Txtbox2.Clear()


        'urn False
        ' End If
        Return True

    End Function


    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)


        Dim adminLog As New AdminLog()
        adminLog.ShowDialog()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Dim staffLogin As New StaffLogin()
        staffLogin.ShowDialog()
    End Sub

End Class