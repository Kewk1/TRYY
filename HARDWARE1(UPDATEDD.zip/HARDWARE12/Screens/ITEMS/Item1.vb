﻿Imports System.Data.SqlClient
Imports System.Security.Cryptography
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Item1


    Private Sub Item1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' BindGD()
        Label7.Text = DataGridView1.RowCount
        Prod()

    End Sub
    Public Sub BindGD()
        qr = "Select * from TblItems where ItemDesc = '" & TextBox2.Text & "'"
        ds = Searchdata(qr)
        If (ds.Tables(0).Rows.Count > 0) Then
            DataGridView1.DataSource = ds.Tables(0)

        Else
            MsgBox("Record Not Found", MsgBoxStyle.Critical)

        End If
    End Sub

    Public Sub Prod()
        qr = "Select * from ProdMainte"
        ds = Searchdata(qr)
        If (ds.Tables(0).Rows.Count > 0) Then
            DataGridView1.DataSource = ds.Tables(0)
            Label7.Text = DataGridView1.RowCount
        Else
            ' MsgBox("Record Not Found", MsgBoxStyle.Critical)

        End If
    End Sub

    Private Sub DataGridView1_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles DataGridView1.CellFormatting

        If e.ColumnIndex = DataGridView1.Columns("Stock").Index AndAlso e.RowIndex >= 0 Then

            Dim stockQuantity As Integer = CInt(e.Value)

            Dim warningThreshold As Integer = 5

            If stockQuantity <= 0 Then

                e.CellStyle.BackColor = Color.Red
                e.CellStyle.ForeColor = Color.White
                e.Value = "Out of Stock"
            ElseIf stockQuantity <= warningThreshold Then

                e.CellStyle.BackColor = Color.Yellow


            End If
        End If
    End Sub


    Private Sub Button3_Click(sender As Object, e As EventArgs)
        If (Isformvalid()) Then
            'qr = "insert into TblItems values('" & TextBox4.Text & "','" & TextBox5.Text & "','" & ComboBox1.Text & "')"
            Dim cmd As New SqlCommand("INSERT INTO TblItems VALUES(@txt1, @txt2, @txt3)")
            cmd.Parameters.AddWithValue("@txt1", TextBox4.Text)
            cmd.Parameters.AddWithValue("@txt2", TextBox5.Text)
            cmd.Parameters.AddWithValue("@txt3", ComboBox1.Text)
            'Dim logincorrect As Boolean = Convert.ToBoolean(InsertData(qr))
            If (InsertData(cmd)) Then
                ' BindGD()
                Clr()
                Prod()


                Label7.Text = DataGridView1.RowCount
                MsgBox("Stock added succesfully", MsgBoxStyle.Information)
            Else
                MsgBox("Error record Not saved", MsgBoxStyle.Critical)
            End If
        End If

    End Sub



    Private Function Isformvalid() As Boolean
        If (TextBox5.Text.Trim() = String.Empty) Then
            MsgBox("Username Is required", MsgBoxStyle.Critical)
            TextBox4.Clear()
            TextBox3.Clear()
            TextBox5.Clear()


            Return False

        End If

        If (TextBox4.Text.Trim() = String.Empty) Then
            MsgBox("Username Is required", MsgBoxStyle.Critical)
            TextBox4.Clear()
            TextBox3.Clear()
            TextBox5.Clear()


            Return False
        End If

        If (ComboBox1.Text.Trim() = String.Empty) Then
            MsgBox("Username Is required", MsgBoxStyle.Critical)
            TextBox4.Clear()
            TextBox3.Clear()
            TextBox5.Clear()


            Return False
        End If
        Return True

    End Function


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (Isformvalid()) Then
            qr = "Update ProdMainte Set Description='" & TextBox5.Text & "', Price='" & TextBox1.Text & "', SellingPrice= '" & TextBox2.Text & "', Stock='" & TextBox6.Text & "', Supplier = '" & TextBox4.Text & "', Category='" & ComboBox1.Text & "' where ProductID= '" & Convert.ToInt32(TextBox3.Text) & "'"
            Dim cmd As New SqlCommand("UPDATE ProdMainte SET Description = @txt1, Price = @txt2, SellingPrice = @txt3, Stock = @txt4, Supplier = @txt5, Category = @txt6 WHERE ProductID = @id")
            cmd.Parameters.AddWithValue("@txt1", TextBox5.Text)
            cmd.Parameters.AddWithValue("@txt2", TextBox1.Text)
            cmd.Parameters.AddWithValue("@txt3", TextBox2.Text)
            cmd.Parameters.AddWithValue("@txt4", TextBox6.Text)
            cmd.Parameters.AddWithValue("@txt5", TextBox4.Text)
            cmd.Parameters.AddWithValue("@txt6", ComboBox1.Text)
            cmd.Parameters.AddWithValue("@id", TextBox3.Text)
            'Dim UpdateTrue As Boolean = Convert.ToBoolean(InsertData(qr))
            If (InsertData(cmd)) Then
                '  BindGD()
                Clr()
                Prod()


                MsgBox("Stock Update succesfully", MsgBoxStyle.Information)


            Else
                MsgBox("error record not saved", MsgBoxStyle.Critical)

            End If

        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim result As Integer = MsgBox("Do you really want to delete record..?", MsgBoxStyle.YesNo)
        If result = DialogResult.No Then
        ElseIf result = DialogResult.Yes Then

            If (Isformvalid2()) Then
                qr = "Delete from ProdMainte where ProductID= '" & Convert.ToInt32(TextBox3.Text) & "'"
                Dim cmd As New SqlCommand("DELETE FROM ProdMainte WHERE ProductID = @id")
                cmd.Parameters.AddWithValue("@id", TextBox3.Text)
                'Dim Wantodelete As Boolean = Convert.ToBoolean(InsertData(qr))
                If (InsertData(cmd)) Then
                    ' BindGD()
                    Clr()
                    Label7.Text = DataGridView1.RowCount

                    MsgBox("Stock Update succesfully", MsgBoxStyle.Information)


                Else
                    MsgBox("error record not saved", MsgBoxStyle.Critical)

                End If
            End If
        End If
    End Sub
    Private Function Isformvalid2() As Boolean
        If (TextBox3.Text.Trim() = String.Empty) Then
            MsgBox("Product ID is required", MsgBoxStyle.Critical)


            Return False


        End If
        Return True

    End Function

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

        qr = "Select * from ProdMainte where Supplier= '" & TextBox7.Text & "'"
        ds = Searchdata(qr)
        If (ds.Tables(0).Rows.Count > 0) Then
            DataGridView1.DataSource = ds.Tables(0)
            i = DataGridView1.CurrentRow.Index
            Me.TextBox3.Text = DataGridView1.Item(0, i).Value
            Me.TextBox4.Text = DataGridView1.Item(6, i).Value
            Me.ComboBox1.Text = DataGridView1.Item(2, i).Value
            Me.TextBox5.Text = DataGridView1.Item(1, i).Value
            Me.TextBox1.Text = DataGridView1.Item(3, i).Value
            Me.TextBox2.Text = DataGridView1.Item(4, i).Value
            Me.TextBox6.Text = DataGridView1.Item(5, i).Value
        Else
            MsgBox("Record Not Found", MsgBoxStyle.Critical)

        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Clr()
        ' BindGD()

    End Sub

    Public Sub Clr()

        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox1.Clear()
        TextBox2.Clear()
    End Sub


    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        i = DataGridView1.CurrentRow.Index
        If (1 > 0) Then
            Me.TextBox3.Text = DataGridView1.Item(0, i).Value
            Me.TextBox4.Text = DataGridView1.Item(6, i).Value
            Me.TextBox5.Text = DataGridView1.Item(1, i).Value
            Me.ComboBox1.Text = DataGridView1.Item(2, i).Value
            Me.TextBox6.Text = DataGridView1.Item(5, i).Value
            Me.TextBox1.Text = DataGridView1.Item(3, i).Value
            Me.TextBox2.Text = DataGridView1.Item(4, i).Value


        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class