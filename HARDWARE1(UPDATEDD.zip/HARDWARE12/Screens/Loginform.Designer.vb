﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Loginform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Txtbox1 = New System.Windows.Forms.TextBox()
        Me.Txtbox2 = New System.Windows.Forms.TextBox()
        Me.Usertxt = New System.Windows.Forms.Label()
        Me.Loginbtn = New System.Windows.Forms.Button()
        Me.passtxt = New System.Windows.Forms.Label()
        Me.Cmbox = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Txtbox1
        '
        Me.Txtbox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtbox1.Location = New System.Drawing.Point(220, 330)
        Me.Txtbox1.MinimumSize = New System.Drawing.Size(23, 4)
        Me.Txtbox1.Name = "Txtbox1"
        Me.Txtbox1.Size = New System.Drawing.Size(135, 26)
        Me.Txtbox1.TabIndex = 0
        Me.Txtbox1.Visible = False
        '
        'Txtbox2
        '
        Me.Txtbox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtbox2.Location = New System.Drawing.Point(220, 362)
        Me.Txtbox2.Name = "Txtbox2"
        Me.Txtbox2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.Txtbox2.Size = New System.Drawing.Size(135, 26)
        Me.Txtbox2.TabIndex = 1
        Me.Txtbox2.Visible = False
        '
        'Usertxt
        '
        Me.Usertxt.AutoSize = True
        Me.Usertxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Usertxt.Image = Global.HARDWARE12.My.Resources.Resources.aaq
        Me.Usertxt.Location = New System.Drawing.Point(45, 354)
        Me.Usertxt.Name = "Usertxt"
        Me.Usertxt.Size = New System.Drawing.Size(91, 20)
        Me.Usertxt.TabIndex = 2
        Me.Usertxt.Text = "Username"
        Me.Usertxt.Visible = False
        '
        'Loginbtn
        '
        Me.Loginbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Loginbtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Loginbtn.Image = Global.HARDWARE12.My.Resources.Resources.aaq
        Me.Loginbtn.Location = New System.Drawing.Point(162, 308)
        Me.Loginbtn.Name = "Loginbtn"
        Me.Loginbtn.Size = New System.Drawing.Size(62, 27)
        Me.Loginbtn.TabIndex = 4
        Me.Loginbtn.Text = "LOGIN"
        Me.Loginbtn.UseVisualStyleBackColor = True
        Me.Loginbtn.Visible = False
        '
        'passtxt
        '
        Me.passtxt.AutoSize = True
        Me.passtxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.passtxt.Image = Global.HARDWARE12.My.Resources.Resources.aaq
        Me.passtxt.Location = New System.Drawing.Point(34, 374)
        Me.passtxt.Name = "passtxt"
        Me.passtxt.Size = New System.Drawing.Size(86, 20)
        Me.passtxt.TabIndex = 3
        Me.passtxt.Text = "Password"
        Me.passtxt.Visible = False
        '
        'Cmbox
        '
        Me.Cmbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmbox.FormattingEnabled = True
        Me.Cmbox.Items.AddRange(New Object() {"Admin", "Staff"})
        Me.Cmbox.Location = New System.Drawing.Point(220, 394)
        Me.Cmbox.Name = "Cmbox"
        Me.Cmbox.Size = New System.Drawing.Size(122, 28)
        Me.Cmbox.TabIndex = 5
        Me.Cmbox.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Image = Global.HARDWARE12.My.Resources.Resources.aaq
        Me.Label1.Location = New System.Drawing.Point(24, 394)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(85, 20)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "UserType"
        Me.Label1.Visible = False
        '
        'Button1
        '
        Me.Button1.Image = Global.HARDWARE12.My.Resources.Resources.aaq
        Me.Button1.Location = New System.Drawing.Point(289, 8)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(55, 27)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "Exit "
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(12, 12)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 8
        Me.Button2.Text = "Back"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(72, 232)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(77, 29)
        Me.Button3.TabIndex = 9
        Me.Button3.Text = "ADMIN"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(204, 232)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(77, 29)
        Me.Button4.TabIndex = 10
        Me.Button4.Text = "STAFF"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(101, 115)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(150, 31)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "LOGIN AS"
        '
        'Loginform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.BackgroundImage = Global.HARDWARE12.My.Resources.Resources.aaq
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(354, 434)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Cmbox)
        Me.Controls.Add(Me.Loginbtn)
        Me.Controls.Add(Me.passtxt)
        Me.Controls.Add(Me.Usertxt)
        Me.Controls.Add(Me.Txtbox2)
        Me.Controls.Add(Me.Txtbox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(23, 43)
        Me.Name = "Loginform"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "LOGINFORM1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Txtbox1 As TextBox
    Friend WithEvents Txtbox2 As TextBox
    Friend WithEvents Usertxt As Label
    Friend WithEvents Loginbtn As Button
    Friend WithEvents passtxt As Label
    Friend WithEvents Cmbox As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Label2 As Label
End Class
