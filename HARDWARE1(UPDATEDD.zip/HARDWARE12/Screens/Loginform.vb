﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Loginform
    Public LoginUser As String
    Public LoginPass As String
    Public UserType As String
    Public q As String




    Private Sub Loginbtn_Click(sender As Object, e As EventArgs) Handles Loginbtn.Click
        If (Isformvalid()) Then
            qr = "select * from Userlogin where Username='" & Txtbox1.Text & "' and password='" & Txtbox2.Text & "'"
            ds = Searchdata(qr)
            If (ds.Tables(0).Rows.Count > 0) Then
                ds = Searchdata(qr)
                LoginUser = Txtbox1.Text
                LoginPass = Txtbox2.Text
                'UserType = Cmbox.Text
                EditUser()
                Admin()
                ' Dboard.Show()
                'AdminLog.Show()

                Me.Hide()


            Else
                'MsgBox("Incorrect Username or Password", MsgBoxStyle.Critical)


            End If
        End If

    End Sub

    Private Sub Admin()
        If Cmbox.SelectedItem = "Staff" Then
            My.Forms.Dboard.PictureBox1.Visible = False
        End If

        If Cmbox.SelectedItem = "Staff" Then


            My.Forms.Dboard.Label2.Visible = False

        End If
    End Sub




    Private Sub EditUser()
        If Cmbox.Text = "Admin" Then
            MsgBox("login in as Admin", MsgBoxStyle.Information)
        Else
            Cmbox.Text = "Staff"
            MsgBox("login in as Staff", MsgBoxStyle.Information)

            q = "insert into UserLoginAudit values('" & Txtbox1.Text & "','" & Txtbox2.Text & " ', '" & Cmbox.Text & "' ,' IN' ,'" & Date.Now & "')"
            Dim cmd As New SqlCommand("INSERT INTO UserLoginAudit VALUES(@txt1, @txt2, @txt3, 'IN', @date1")
            cmd.Parameters.AddWithValue("@txt1", Txtbox1.Text)
            cmd.Parameters.AddWithValue("@txt2", Txtbox2.Text)
            cmd.Parameters.AddWithValue("@txt3", Cmbox.Text)
            cmd.Parameters.Add("@date1", SqlDbType.Date).Value = DateTime.Now
            'Dim logincorrect As Boolean = Convert.ToBoolean(InsertData(q))
            If (InsertData(cmd)) Then

                ' MsgBox("login succesfully", MsgBoxStyle.Information)
            Else
                ' MsgBox("Incorrect User or Password..", MsgBoxStyle.Critical)
            End If



        End If
    End Sub

    Private Function Isformvalid() As Boolean
        If (Txtbox1.Text.Trim() = String.Empty) Then
            MsgBox("Username is required", MsgBoxStyle.Critical)
            Txtbox1.Clear()
            Txtbox2.Clear()
            Return False

        End If

        If (Txtbox2.Text.Trim() = String.Empty) Then
            MsgBox("Password is required", MsgBoxStyle.Critical)
            Txtbox1.Clear()
            Txtbox2.Clear()
            Return False
        End If


        ' If (Cmbox.SelectedIndex = -1) Then
        'MsgBox("Choose User", MsgBoxStyle.Critical)
        'Txtbox1.Clear()
        'Txtbox2.Clear()


        'urn False
        ' End If
        Return True

    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Application.Exit()


    End Sub

    Private Sub Loginform_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Button2.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dboard.Show()
        Me.Hide()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Hide()

        Dim adminLog As New AdminLog()
        adminLog.ShowDialog()

    End Sub



    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles Button4.Click

        Dim staffLogin As New StaffLogin()
        staffLogin.ShowDialog()
        Me.Hide()
    End Sub
End Class
