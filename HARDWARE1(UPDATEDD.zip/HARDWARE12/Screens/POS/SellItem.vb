﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class SellItem
    Public q As String

    Private Sub SellItem_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BindGD()
    End Sub

    Public Sub BindGD()
        qr = "Select * from ProdMainte"
        'qr = "Select * from tblProductInfo"
        ds = Searchdata(qr)
        If (ds.Tables(0).Rows.Count > 0) Then
            DataGridView1.DataSource = ds.Tables(0)

        Else
            'MsgBox("Record Not Found", MsgBoxStyle.Critical)

        End If
    End Sub




    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        qr = "Select * from ProdMainte where Category= '" & TextBox1.Text & "'"
        'qr = "Select * from tblProductInfo where ProductCategory= '" & TextBox1.Text & "'"
        ds = Searchdata(qr)
        If (ds.Tables(0).Rows.Count > 0) Then
            DataGridView1.DataSource = ds.Tables(0)
            i = DataGridView1.CurrentRow.Index
            Me.TextBox2.Text = DataGridView1.Item(0, i).Value
            Me.TextBox3.Text = DataGridView1.Item(1, i).Value
            Me.TextBox4.Text = DataGridView1.Item(2, i).Value
            Me.TextBox5.Text = DataGridView1.Item(3, i).Value
            Me.TextBox6.Text = DataGridView1.Item(4, i).Value

        Else
            MsgBox("Record Not Found", MsgBoxStyle.Critical)

        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        BindGD()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()

    End Sub

    Private Sub TextBox9_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBox9.KeyUp
        Dim tot, rcash, num As Integer
        tot = Val(TextBox8.Text)
        rcash = Val(TextBox9.Text)

        If rcash = tot Then

            TextBox10.Text = 0
        ElseIf rcash > tot Then
            num = rcash - tot
            'MsgBox("not enought cash...")
            TextBox10.Text = num.ToString()
        ElseIf rcash < tot Then
            num = rcash - tot
            TextBox10.Text = num.ToString


        End If
    End Sub



    Private Sub TextBox7_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBox7.KeyUp
        If TextBox7.Text.Trim() = "" Then
            MsgBox("Enter Product pcs")
        Else
            TextBox8.Text = Val(TextBox5.Text) * Val(TextBox7.Text)

        End If

    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        i = DataGridView1.CurrentRow.Index
        If (1 > 0) Then
            Me.TextBox2.Text = DataGridView1.Item(0, i).Value
            Me.TextBox3.Text = DataGridView1.Item(1, i).Value
            Me.TextBox4.Text = DataGridView1.Item(2, i).Value
            Me.TextBox5.Text = DataGridView1.Item(4, i).Value
            Me.TextBox6.Text = DataGridView1.Item(5, i).Value
        End If

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        TextBox7.Clear()
        TextBox8.Clear()
        TextBox9.Clear()
        TextBox10.Clear()

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub




    Private Sub EditAudit()
        If (Isformvalid()) Then
            'q = "insert into ProSaleAudit values('" & TextBox2.Text & "','" & TextBox3.Text & " ' , '" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "','" & DateTime.Now & "')"
            Dim cmd As New SqlCommand("INSERT INTO ProSaleAudit VALUES(@txt1, @txt2, @txt3, @txt4, @txt5, @txt6, @date)")
            cmd.Parameters.AddWithValue("@txt1", TextBox2.Text)
            cmd.Parameters.AddWithValue("@txt2", TextBox3.Text)
            cmd.Parameters.AddWithValue("@txt3", TextBox4.Text)
            cmd.Parameters.AddWithValue("@txt4", TextBox5.Text)
            cmd.Parameters.AddWithValue("@txt5", TextBox7.Text)
            cmd.Parameters.AddWithValue("@txt6", TextBox8.Text)
            cmd.Parameters.Add("@date", SqlDbType.Date).Value = DateTime.Now
            'Dim logincorrect As Boolean = Convert.ToBoolean(InsertData(q))
            If (InsertData(cmd)) Then

            Else
                MsgBox("Incorrect User or Password..", MsgBoxStyle.Critical)
            End If



        End If
    End Sub


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If (Isformvalid()) Then
            qr = "insert into ProSale values('" & Convert.ToInt32(TextBox2.Text) & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox7.Text & "','" & TextBox5.Text & "','" & TextBox8.Text & "','" & DateTime.Now & "','" & My.Forms.Dboard.LoggedUser.Text & "')"
            Dim cmd As New SqlCommand("INSERT INTO ProSale VALUES(@txt1, @txt2, @txt3, @txt4,@txt5,@txt6,@txt7,@txt8)")
            cmd.Parameters.AddWithValue("@txt1", TextBox2.Text)
            cmd.Parameters.AddWithValue("@txt2", TextBox3.Text)
            cmd.Parameters.AddWithValue("@txt3", TextBox4.Text)
            cmd.Parameters.AddWithValue("@txt4", TextBox7.Text)
            cmd.Parameters.AddWithValue("@txt5", TextBox5.Text)
            cmd.Parameters.AddWithValue("@txt6", TextBox8.Text)
            cmd.Parameters.AddWithValue("@txt7", SqlDbType.Date).Value = DateTime.Now
            cmd.Parameters.AddWithValue("@txt8", My.Forms.Dboard.LoggedUser.Text)
            'Dim logincorrect As Boolean = Convert.ToBoolean(InsertData(qr))
            If InsertData(cmd) Then

                BindGD()
                ' EditAudit()
                UpdateStock()

                ' MsgBox("sold", MsgBoxStyle.Information)
            Else

                MsgBox("Error record Not saved", MsgBoxStyle.Critical)

            End If



        End If
    End Sub



    Public Sub UpdateStock()
        If (Isformvalid()) Then
            Dim c As String

            c = Val(TextBox6.Text) - Val(TextBox7.Text)

            If Val(TextBox6.Text) >= Val(TextBox7.Text) Then
                c = Val(TextBox6.Text) - Val(TextBox7.Text)
                'qr = "Update ProdMainte Set Stock='" & c & "' where ProductID='" & Convert.ToInt32(TextBox2.Text) & "'"
                ' qr = "Update tblProductInfo Set Prostock='" & c & "' where ProID='" & Convert.ToInt32(TextBox2.Text) & "'"
                Dim cmd As New SqlCommand("UPDATE ProdMainte SET Stock = @txt1 WHERE ProductID = @id")
                cmd.Parameters.AddWithValue("@txt1", c)
                cmd.Parameters.AddWithValue("@id", TextBox2.Text)

                'Dim UpdateTrue As Boolean = Convert.ToBoolean(InsertData(qr))
                If (InsertData(cmd)) Then



                    BindGD()


                    ' MsgBox("Sold", MsgBoxStyle.Information)
                    'End If
                    'If Stock <= Pcs Then

                    'MsgBox("not enought", MsgBoxStyle.Critical)



                    ' MsgBox("error record not saved", MsgBoxStyle.Critical)
                End If
                MsgBox("DONE", MsgBoxStyle.Information)
            Else
                If Val(TextBox6.Text) <= Val(TextBox7.Text) Then

                    MsgBox("Not enough stock", MsgBoxStyle.Critical)
                End If
            End If


        End If
        ' End If







    End Sub

    Private Function Isformvalid() As Boolean
        If (TextBox4.Text.Trim() = String.Empty) Then
            'MsgBox("Username Is required", MsgBoxStyle.Critical)
            TextBox4.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox5.Clear()


            Return False

        End If

        If (TextBox3.Text.Trim() = String.Empty) Then
            'MsgBox("Username Is required", MsgBoxStyle.Critical)
            TextBox4.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox5.Clear()


            Return False
        End If

        If (TextBox5.Text.Trim() = String.Empty) Then
            'MsgBox("Username Is required", MsgBoxStyle.Critical)
            TextBox4.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox5.Clear()


            Return False
        End If
        Return True

    End Function

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim dispercent As Double
        If ComboBox1.Text > 0 Then
            dispercent = Convert.ToDouble(Val(TextBox8.Text) * Val(ComboBox1.Text) / 100)
            TextBox8.Text = Val(TextBox8.Text) - dispercent.ToString()
            TextBox11.Text = dispercent.ToString()
        Else
            TextBox5.Text = Val(TextBox5.Text) * Val(TextBox7.Text).ToString()
            TextBox11.Clear()
            TextBox8.Clear()


        End If
    End Sub
End Class