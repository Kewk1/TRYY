﻿Imports System.Reflection.Emit
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Salesfrm

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        BindGD()
        Sum()


    End Sub

    Private Sub Salesfrm_Load(sender As Object, e As EventArgs) Handles MyBase.Load





    End Sub
    Public Sub BindGD()
        qr = "Select * from ProsaleAudit"
        ds = Searchdata(qr)
        If (ds.Tables(0).Rows.Count > 0) Then
            DataGridView1.DataSource = ds.Tables(0)
            TextBox2.Text = DataGridView1.RowCount
        Else
            'MsgBox("Record Not Found", MsgBoxStyle.Critical)

        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub


    Private Sub Label5_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs)


    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Sum()

    End Sub
    Public Sub Sum()
        BindGD()

        Dim Sum As Decimal = 0
        For i = 0 To DataGridView1.Rows.Count - 1
            Sum += DataGridView1.Rows(i).Cells(6).Value

        Next
        TextBox1.Text = Sum
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        Sum()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged
        DateTimePicker1.Hide()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        DateTimePicker1.Show()

    End Sub
End Class