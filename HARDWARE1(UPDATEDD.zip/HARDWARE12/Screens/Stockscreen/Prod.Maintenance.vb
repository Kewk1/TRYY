﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Maintenance
    Public q As String


    Private Sub Addbtn_Click(sender As Object, e As EventArgs) Handles Addbtn.Click
        If (Isformvalid()) Then
            'qr = "insert into tblProductInfo values('" & Txtbox2.Text & "','" & Txtbox3.Text & "','" & txtbox4.Text & "','" & txtbox5.Text & "','" & My.Forms.Dboard.LoggedUser.Text & "','" & DateTime.Now & "')"
            Dim cmd As New SqlCommand("INSERT INTO tblProductInfo VALUES(@txt1, @txt2, @txt3, @txt4, @txt5, @date1")
            cmd.Parameters.AddWithValue("@txt1", Txtbox2.Text)
            cmd.Parameters.AddWithValue("@txt2", Txtbox3.Text)
            cmd.Parameters.AddWithValue("@txt3", txtbox4.Text)
            cmd.Parameters.AddWithValue("@txt4", txtbox5.Text)
            cmd.Parameters.AddWithValue("@txt5", My.Forms.Dboard.LoggedUser.Text)
            cmd.Parameters.Add("@date1", SqlDbType.Date).Value = DateTime.Now
            'Dim logincorrect As Boolean = Convert.ToBoolean(InsertData(qr))
            If (InsertData(cmd)) Then
                BindGD()
                ' EditUser()



                MsgBox("Stock added succesfully", MsgBoxStyle.Information)
            Else
                MsgBox("Error record Not saved", MsgBoxStyle.Critical)

            End If



        End If
    End Sub


    'Private Sub EditUser()
    'If (Isformvalid()) Then
    ' q = "insert into tblProductInfoAudit values('" & Prodidbox.Text & "','" & Txtbox2.Text & " ' , '" & Txtbox3.Text & "','" & txtbox4.Text & "','" & txtbox5.Text & "')"
    'Dim logincorrect As Boolean = Convert.ToBoolean(InsertData(q))
    'If (logincorrect) Then

    '            MsgBox("login succesfully", MsgBoxStyle.Information)
    'Else
    'End If



    'End If
    'End Sub



    Private Function Isformvalid() As Boolean
        If (txtbox4.Text.Trim() = String.Empty) Then
            'MsgBox("Username Is required", MsgBoxStyle.Critical)
            txtbox4.Clear()
            Txtbox2.Clear()
            Txtbox3.Clear()
            txtbox5.Clear()


            Return False

        End If

        If (Txtbox3.Text.Trim() = String.Empty) Then
            'MsgBox("Username Is required", MsgBoxStyle.Critical)
            txtbox4.Clear()
            Txtbox2.Clear()
            Txtbox3.Clear()
            txtbox5.Clear()


            Return False
        End If

        If (txtbox5.Text.Trim() = String.Empty) Then
            'MsgBox("Username Is required", MsgBoxStyle.Critical)
            txtbox4.Clear()
            Txtbox2.Clear()
            Txtbox3.Clear()
            txtbox5.Clear()


            Return False
        End If
        Return True

    End Function

    Public Sub BindGD()
        qr = "Select * from ProdMainte"

        ds = Searchdata(qr)
        If (ds.Tables(0).Rows.Count > 0) Then
            DataGridView1.DataSource = ds.Tables(0)
        Else
            'MsgBox("record Not found", MsgBoxStyle.Critical)

        End If
    End Sub
    Public Sub Clr()
        Prodidbox.Clear()
        Txtbox2.Clear()
        Txtbox3.Clear()
        txtbox4.Clear()
        txtbox5.Clear()
        TextBox1S.Clear()


    End Sub

    Private Sub DataGridView1_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles DataGridView1.CellFormatting

        If e.ColumnIndex = DataGridView1.Columns("Stock").Index AndAlso e.RowIndex >= 0 Then

            Dim stockQuantity As Integer = CInt(e.Value)


            Dim warningThreshold As Integer = 5

            If stockQuantity <= 0 Then

                e.CellStyle.BackColor = Color.Red
                e.CellStyle.ForeColor = Color.White
                e.Value = "Out of Stock"
            ElseIf stockQuantity <= warningThreshold Then

                e.CellStyle.BackColor = Color.Yellow

            End If
        End If
    End Sub

    Private Sub Addsctock_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BindGD()
        Addbtn.Enabled = False
        Updtbtn.Enabled = False
        Dltbtn.Enabled = False


    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs)

    End Sub





    Private Sub Updtbtn_Click(sender As Object, e As EventArgs) Handles Updtbtn.Click
        If (Isformvalid()) Then
            'qr = "Update ProdMainte Set Description='" & Txtbox3.Text & "', Category= '" & ComboBox1.Text & "', SellingPrice='" & txtbox4.Text & "', Stock='" & txtbox5.Text & "', Supplier='" & TextBox1.Text & "' where ProductID= '" & Convert.ToInt32(Prodidbox.Text) & "'"
            Dim cmd As New SqlCommand("UPDATE ProdMainte SET Description = @txt1, SellingPrice = @txt3, Stock = @txt4, Supplier = @txt5, Category = @txt6 WHERE ProductID = @id")
            cmd.Parameters.AddWithValue("@txt1", Txtbox3.Text)
            cmd.Parameters.AddWithValue("@txt3", txtbox4.Text)
            cmd.Parameters.AddWithValue("@txt4", txtbox5.Text)
            cmd.Parameters.AddWithValue("@txt5", TextBox1.Text)
            cmd.Parameters.AddWithValue("@txt6", ComboBox1.Text)
            cmd.Parameters.AddWithValue("@id", Prodidbox.Text)
            'Dim UpdateTrue As Boolean = Convert.ToBoolean(InsertData(qr))
            If (InsertData(cmd)) Then
                BindGD()



                MsgBox("Stock Update succesfully", MsgBoxStyle.Information)


            Else
                MsgBox("error record not saved", MsgBoxStyle.Critical)

            End If

        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        i = DataGridView1.CurrentRow.Index
        If (1 > 0) Then
            Me.Prodidbox.Text = DataGridView1.Item(0, i).Value
            Me.Txtbox3.Text = DataGridView1.Item(1, i).Value
            Me.txtbox4.Text = DataGridView1.Item(4, i).Value
            Me.txtbox5.Text = DataGridView1.Item(5, i).Value
            Me.TextBox1.Text = DataGridView1.Item(6, i).Value
            'Me.TextBox1.Text = DataGridView1.Item(5, i).Value
            Me.ComboBox1.Text = DataGridView1.Item(2, i).Value



            Addbtn.Enabled = False
            Updtbtn.Enabled = True
            Dltbtn.Enabled = True
        End If
    End Sub

    Private Sub Cancelbtn_Click(sender As Object, e As EventArgs) Handles Cancelbtn.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Clr()

        Txtbox2.Focus()
        Addbtn.Enabled = True
        Updtbtn.Enabled = False
        Dltbtn.Enabled = False
    End Sub

    Private Sub Dltbtn_Click(sender As Object, e As EventArgs) Handles Dltbtn.Click
        Dim result As Integer = MsgBox("Do you really want to delete record..?", MsgBoxStyle.YesNo)
        If result = DialogResult.No Then
        ElseIf result = DialogResult.Yes Then

            If (Isformvalid2()) Then
                'qr = "Delete from ProdMainte where ProID= '" & Convert.ToInt32(Prodidbox.Text) & "'"
                Dim cmd As New SqlCommand("DELETE FROM ProdMainte WHERE ProID = @id")
                cmd.Parameters.AddWithValue("@id", Prodidbox.Text)
                'Dim Wantodelete As Boolean = Convert.ToBoolean(InsertData(qr))
                If (InsertData(cmd)) Then
                    BindGD()
                    ' EditUser()


                    MsgBox("Stock Update succesfully", MsgBoxStyle.Information)


                Else
                    MsgBox("error record not saved", MsgBoxStyle.Critical)

                End If
            End If
        End If


    End Sub

    Private Function Isformvalid2() As Boolean
        If (Prodidbox.Text.Trim() = String.Empty) Then
            MsgBox("Product ID is required", MsgBoxStyle.Critical)


            Return False


        End If
        Return True

    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        qr = "Select * from tblProductInfo where ProID= '" & Convert.ToInt32(TextBox1S.Text) & "'"
        ds = Searchdata(qr)
        If (ds.Tables(0).Rows.Count > 0) Then
            DataGridView1.DataSource = ds.Tables(0)
            'EditUser()


        Else
            MsgBox("Record Not Found", MsgBoxStyle.Critical)

        End If

    End Sub

    Private Sub TextBox1S_TextChanged(sender As Object, e As EventArgs) Handles TextBox1S.TextChanged


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        BindGD()
        Clr()

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs)

    End Sub
End Class

