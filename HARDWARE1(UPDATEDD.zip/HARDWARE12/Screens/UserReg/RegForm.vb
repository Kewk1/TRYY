﻿Public Class RegForm
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        RegistrationForm.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        StaffRegistration.Show()

    End Sub
End Class