﻿Imports System.Data.SqlClient

Public Class StaffRegistration
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click





        If (Isformvalid()) Then
            qr = "insert into StaffLogin values('" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & ComboBox1.Text & "')"
            'Dim logincorrect As Boolean = Convert.ToBoolean(InsertData(qr))
            Dim cmd As New SqlCommand("INSERT INTO StaffLogin VALUES(@txt1, @txt2, @txt3, @txt4, @txt5)")
            cmd.Parameters.AddWithValue("@txt1", TextBox2.Text)
                cmd.Parameters.AddWithValue("@txt2", TextBox3.Text)
                cmd.Parameters.AddWithValue("@txt3", TextBox4.Text)
                cmd.Parameters.AddWithValue("@txt4", TextBox5.Text)
                cmd.Parameters.AddWithValue("@txt5", ComboBox1.Text)
                If (InsertData(cmd)) Then

                    MsgBox("New Account added succesfully", MsgBoxStyle.Information)
                Else
                    MsgBox("Error.. Acc Not saved", MsgBoxStyle.Critical)
                End If
            End If
        End Sub

        Private Function Isformvalid() As Boolean
            If (TextBox1.Text.Trim() = String.Empty) Then
                MsgBox("Username Is required", MsgBoxStyle.Critical)
                TextBox4.Clear()
                TextBox2.Clear()
                TextBox3.Clear()



                Return False

            End If

            If (TextBox3.Text.Trim() = String.Empty) Then
                MsgBox("Username Is required", MsgBoxStyle.Critical)
                TextBox4.Clear()
                TextBox2.Clear()
                TextBox1.Clear()



                Return False
            End If

            If (ComboBox1.SelectedIndex = -1) Then
                MsgBox("Username Is required", MsgBoxStyle.Critical)
                TextBox4.Clear()
                TextBox2.Clear()
                TextBox3.Clear()



                Return False
            End If
            Return True

        End Function



        Private Sub RegistrationForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BindGD()
        Label7.Text = DataGridView1.RowCount
        End Sub



    Public Sub BindGD()
        qr = "Select * from StaffLogin"
        ds = Searchdata(qr)
            If (ds.Tables(0).Rows.Count > 0) Then
                DataGridView1.DataSource = ds.Tables(0)

            Else
                'MsgBox("Record Not Found", MsgBoxStyle.Critical)

            End If
        End Sub
        Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
            i = DataGridView1.CurrentRow.Index
            If (1 > 0) Then
                Me.TextBox2.Text = DataGridView1.Item(0, i).Value
                Me.TextBox3.Text = DataGridView1.Item(1, i).Value
                Me.TextBox4.Text = DataGridView1.Item(2, i).Value
                Me.TextBox5.Text = DataGridView1.Item(3, i).Value
                Me.ComboBox1.Text = DataGridView1.Item(4, i).Value
            End If
        End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dboard.Show()
        My.Forms.StaffRegistration.Close()
    End Sub
End Class