﻿Imports System.Data.SqlClient
Imports System.Security.Cryptography
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class AddSupProd
    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        qr = "insert into SpProd  values('" & TextBox2.Text & "','" & ComboBox1.Text & "','" & TextBox3.Text & "','" & TextBox6.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & DateTime.Now & "')"
        'Dim logincorrect As Boolean = Convert.ToBoolean(InsertData(qr))
        Dim cmd As New SqlCommand("INSERT INTO SpProd VALUES(@txt1, @txt2, @txt3, @txt4, @txt5, @txt6, @date1)")
        cmd.Parameters.AddWithValue("@txt1", TextBox2.Text)
        cmd.Parameters.AddWithValue("@txt2", ComboBox1.Text)
        cmd.Parameters.AddWithValue("@txt3", TextBox3.Text)
        cmd.Parameters.AddWithValue("@txt4", TextBox6.Text)
        cmd.Parameters.AddWithValue("@txt5", TextBox4.Text)
        cmd.Parameters.AddWithValue("@txt6", TextBox5.Text)
        cmd.Parameters.AddWithValue("@date1", DateTime.Now).DbType = SqlDbType.DateTime
        If (InsertData(cmd)) Then
            'BindGD()
            ' EditUser()



            MsgBox("Stock added succesfully", MsgBoxStyle.Information)
        Else
            MsgBox("Error record Not saved", MsgBoxStyle.Critical)
        End If

    End Sub
    Public Sub Suppname()
        qr = "Select * from Supp where Supplier = '" & TextBox5.Text & "'"


        ds = Searchdata(qr)
        If (ds.Tables(0).Rows.Count > 0) Then
            My.Forms.StockItem.DataGridView1.DataSource = ds.Tables(0)
        Else
            'MsgBox("record Not found", MsgBoxStyle.Critical)

        End If
    End Sub

    Private Sub AddSupProd_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class