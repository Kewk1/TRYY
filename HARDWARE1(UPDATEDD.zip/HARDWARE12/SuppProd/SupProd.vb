﻿Imports System.Data.SqlClient
Imports System.Reflection.Emit

Public Class SupProd
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub SupProd_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BindGd()
        Ttry()

    End Sub
    Public Sub BindGd()
        qr = "select * from SpProd"
        ds = Searchdata(qr)

        If (ds.Tables(0).Rows.Count > 0) Then
            DataGridView1.DataSource = ds.Tables(0)
        Else
            'MsgBox("record Not found", MsgBoxStyle.Critical)

        End If
    End Sub
    Public Sub Ttry()
        DataGridView1.Columns(4).Visible = False

    End Sub


    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        i = DataGridView1.CurrentRow.Index
        If (1 > 0) Then
            Me.TextBox1.Text = DataGridView1.Item(0, i).Value
            Me.TextBox2.Text = DataGridView1.Item(1, i).Value
            Me.ComboBox1.Text = DataGridView1.Item(2, i).Value
            Me.TextBox3.Text = DataGridView1.Item(3, i).Value
            Me.TextBox4.Text = DataGridView1.Item(5, i).Value
            Me.TextBox5.Text = DataGridView1.Item(6, i).Value

        End If
    End Sub


    Public Sub Del()
        Dim result As Integer = MsgBox("Do you really want to delete record..?", MsgBoxStyle.YesNo)
        If result = DialogResult.No Then
        ElseIf result = DialogResult.Yes Then


            'qr = "Delete from SpProd where ProductID= '" & Convert.ToInt32(TextBox1.Text) & "'"
            Dim cmd As New SqlCommand("DELETE FROM SpProd WHERE ProductID = @id")
            cmd.Parameters.AddWithValue("@id", TextBox1.Text)
            'Dim Wantodelete As Boolean = Convert.ToBoolean(InsertData(qr))
            If (InsertData(cmd)) Then
                ' BindGD()



                ' MsgBox("Stock Update succesfully", MsgBoxStyle.Information)


            Else
                ' MsgBox("error record not saved", MsgBoxStyle.Critical)
            End If

        End If

    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'qr = "insert into ProdMainte values('" & TextBox2.Text & "','" & ComboBox1.Text & "','" & TextBox3.Text & "','" & TextBox6.Text & "','" & TextBox4.Text & "', '" & TextBox5.Text & " ','" & DateTime.Now & "')"
        Dim cmd As New SqlCommand("INSERT INTO ProdMainte VALUES(@txt1, @txt2, @txt3, @txt4, @txt5, @txt6, @date1)")
        cmd.Parameters.AddWithValue("@txt1", TextBox2.Text)
        cmd.Parameters.AddWithValue("@txt2", ComboBox1.Text)
        cmd.Parameters.AddWithValue("@txt3", TextBox3.Text)
        cmd.Parameters.AddWithValue("@txt4", TextBox6.Text)
        cmd.Parameters.AddWithValue("@txt5", TextBox4.Text)
        cmd.Parameters.AddWithValue("@txt6", TextBox5.Text)
        cmd.Parameters.AddWithValue("@date1", DateTime.Now).DbType = SqlDbType.DateTime
        'Dim logincorrect As Boolean = Convert.ToBoolean(InsertData(qr))
        If (InsertData(cmd)) Then
            'BindGd()
            Del()


            MsgBox("DONE", MsgBoxStyle.Information)
        Else
            MsgBox("S", MsgBoxStyle.Critical)
        End If

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class